const express = require('express');
const router = express.Router();
const workshopsController = require('../controllers/workshopsController');

router.get('/workshops', workshopsController.getWorkshops);
router.get('/workshops/:id', workshopsController.getWorkshop);
router.post('/workshops', workshopsController.createWorkshop);
router.put('/workshops/:id', workshopsController.updateWorkshop);
router.delete('/workshops/:id', workshopsController.deleteWorkshop);
router.get('/recommendations', workshopsController.getRecommendedWorkshops);

module.exports = router;

