const express = require('express');
const router = express.Router();
const recipesController = require('../controllers/recipesController');

router.get('/recipes', recipesController.getRecipes);
router.get('/recipes/:id', recipesController.getRecipe);
router.post('/recipes', recipesController.createRecipe);
router.put('/recipes/:id', recipesController.updateRecipe);
router.delete('/recipes/:id', recipesController.deleteRecipe);
router.get('/recipes/:id/ingredients', recipesController.getIngredientsList);

module.exports = router;
