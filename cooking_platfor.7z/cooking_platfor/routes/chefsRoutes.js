const express = require('express');
const router = express.Router();
const client = require('../config/db'); // Подключение к базе данных

// Получение списка шефов
router.get('/chefs', async (req, res) => {
    try {
        const result = await client.query('SELECT id, name FROM chefs');
        res.json(result.rows);
    } catch (err) {
        console.error(err.stack);
        res.status(500).json({ error: 'Database error' });
    }
});

module.exports = router;
