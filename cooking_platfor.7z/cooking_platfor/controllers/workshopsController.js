const workshopModel = require('../models/workshopModel');

const getWorkshops = async (req, res) => {
    try {
        const workshops = await workshopModel.getAllWorkshops();
        res.status(200).json(workshops);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getWorkshop = async (req, res) => {
    try {
        const workshop = await workshopModel.getWorkshopById(req.params.id);
        if (!workshop) {
            return res.status(404).json({ message: 'Workshop not found' });
        }
        res.status(200).json(workshop);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const createWorkshop = async (req, res) => {
    const { chef_id, title, date, video_url } = req.body;
    if (!chef_id || !title || !date) {
        return res.status(400).json({ message: 'Missing required fields: chef_id, title, date' });
    }
    try {
        const newWorkshop = await workshopModel.addWorkshop(chef_id, title, date, video_url);
        res.status(201).json(newWorkshop);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const updateWorkshop = async (req, res) => {
    const { chef_id, title, date, video_url } = req.body;
    if (!chef_id || !title || !date) {
        return res.status(400).json({ message: 'Missing required fields: chef_id, title, date' });
    }
    try {
        const updatedWorkshop = await workshopModel.updateWorkshop(req.params.id, chef_id, title, date, video_url);
        if (!updatedWorkshop) {
            return res.status(404).json({ message: 'Workshop not found' });
        }
        res.status(200).json(updatedWorkshop);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const deleteWorkshop = async (req, res) => {
    try {
        const deletedWorkshop = await workshopModel.deleteWorkshop(req.params.id);
        if (!deletedWorkshop) {
            return res.status(404).json({ message: 'Workshop not found' });
        }
        res.status(200).json({ message: 'Workshop deleted', workshop: deletedWorkshop });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getRecommendedWorkshops = async (req, res) => {
    const user_id = req.query.user_id;
    if (!user_id) {
        return res.status(400).json({ message: 'Missing required parameter: user_id' });
    }
    try {
        const recommendations = await workshopModel.getRecommendedWorkshops(user_id);
        res.status(200).json(recommendations);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = { getWorkshops, getWorkshop, createWorkshop, updateWorkshop, deleteWorkshop, getRecommendedWorkshops };
