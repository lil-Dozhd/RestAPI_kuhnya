const db = require('../config/db');

const getAllWorkshops = async () => {
    try {
        const result = await db.query('SELECT * FROM workshops');
        return result.rows;
    } catch (error) {
        throw new Error('Error fetching workshops: ' + error.message);
    }
};

const getWorkshopById = async (id) => {
    try {
        const result = await db.query('SELECT * FROM workshops WHERE id = $1', [id]);
        return result.rows[0];
    } catch (error) {
        throw new Error('Error fetching workshop: ' + error.message);
    }
};

const addWorkshop = async (chef_id, title, date, video_url) => {
    try {
        const result = await db.query(
            'INSERT INTO workshops (chef_id, title, date, video_url) VALUES ($1, $2, $3, $4) RETURNING *',
            [chef_id, title, date, video_url]
        );
        return result.rows[0];
    } catch (error) {
        throw new Error('Error adding workshop: ' + error.message);
    }
};

const updateWorkshop = async (id, chef_id, title, date, video_url) => {
    try {
        const result = await db.query(
            'UPDATE workshops SET chef_id = $1, title = $2, date = $3, video_url = $4 WHERE id = $5 RETURNING *',
            [chef_id, title, date, video_url, id]
        );
        return result.rows[0];
    } catch (error) {
        throw new Error('Error updating workshop: ' + error.message);
    }
};

const deleteWorkshop = async (id) => {
    try {
        const result = await db.query('DELETE FROM workshops WHERE id = $1 RETURNING *', [id]);
        return result.rows[0];
    } catch (error) {
        throw new Error('Error deleting workshop: ' + error.message);
    }
};

const getRecommendedWorkshops = async (user_id) => {
    try {
        const result = await db.query(`
            SELECT w.*
            FROM workshops w
            JOIN subscriptions s ON w.chef_id = s.chef_id
            WHERE s.user_id = $1
            AND w.date > NOW()
            ORDER BY w.date ASC
            LIMIT 5
        `, [user_id]);
        return result.rows;
    } catch (error) {
        throw new Error('Error fetching recommendations: ' + error.message);
    }
};

module.exports = { getAllWorkshops, getWorkshopById, addWorkshop, updateWorkshop, deleteWorkshop, getRecommendedWorkshops };
