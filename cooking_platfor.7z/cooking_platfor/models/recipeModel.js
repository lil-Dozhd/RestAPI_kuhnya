const db = require('../config/db');

const getAllRecipes = async () => {
    try {
        const result = await db.query('SELECT * FROM recipes');
        return result.rows;
    } catch (error) {
        throw new Error('Error fetching recipes: ' + error.message);
    }
};

const getRecipeById = async (id) => {
    try {
        const result = await db.query('SELECT * FROM recipes WHERE id = $1', [id]);
        return result.rows[0];
    } catch (error) {
        throw new Error('Error fetching recipe: ' + error.message);
    }
};

const addRecipe = async (chef_id, title, ingredients, instructions) => {
    try {
        const result = await db.query(
            'INSERT INTO recipes (chef_id, title, ingredients, instructions) VALUES ($1, $2, $3, $4) RETURNING *',
            [chef_id, title, ingredients, instructions]
        );
        return result.rows[0];
    } catch (error) {
        throw new Error('Error adding recipe: ' + error.message);
    }
};

const updateRecipe = async (id, chef_id, title, ingredients, instructions) => {
    try {
        const result = await db.query(
            'UPDATE recipes SET chef_id = $1, title = $2, ingredients = $3, instructions = $4 WHERE id = $5 RETURNING *',
            [chef_id, title, ingredients, instructions, id]
        );
        return result.rows[0];
    } catch (error) {
        throw new Error('Error updating recipe: ' + error.message);
    }
};

const deleteRecipe = async (id) => {
    try {
        const result = await db.query('DELETE FROM recipes WHERE id = $1 RETURNING *', [id]);
        return result.rows[0];
    } catch (error) {
        throw new Error('Error deleting recipe: ' + error.message);
    }
};

const getIngredientsList = async (id) => {
    try {
        const result = await db.query('SELECT ingredients FROM recipes WHERE id = $1', [id]);
        if (!result.rows[0]) {
            throw new Error('Recipe not found');
        }
        return result.rows[0].ingredients.split(',').map(item => item.trim());
    } catch (error) {
        throw new Error('Error fetching ingredients: ' + error.message);
    }
};

module.exports = { getAllRecipes, getRecipeById, addRecipe, updateRecipe, deleteRecipe, getIngredientsList };
